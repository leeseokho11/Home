package nowon.service.impl;


import java.io.File;
import java.io.IOException;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import lombok.extern.log4j.Log4j2;
import nowon.domain.dto.visual.SaveDto;
import nowon.service.VisualService;

@Log4j2
@Service
public class VisualServiceImpl implements VisualService {

	@Override
	public void saveAndFileUpload(MultipartFile visualFile, SaveDto dto) throws IOException {
		
		long fileSize=visualFile.getSize();
		String fileName=visualFile.getOriginalFilename();
		
		/*
		String filePath="/images/visual";
		ClassPathResource cpr=new ClassPathResource("static" + filePath);
		File location= cpr.getFile();
		visualFile.transferTo(new File());
		*/
		
		//리눅스 물리 경로에 업로드하는 방법
		String location="/home/ec2-user/src/root";
		String filePath ="/file/visual"; 
		visualFile.transferTo(new File(location+filePath, fileName));
		log.debug("파일업로드 완료!");
		
	}

}
