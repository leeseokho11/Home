package nowon.service.impl;

import org.springframework.stereotype.Service;

import nowon.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService{

}
