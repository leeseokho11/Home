package nowon.service;

public interface BoardService {

}
