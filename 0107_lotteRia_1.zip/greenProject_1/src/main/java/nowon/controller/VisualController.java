package nowon.controller;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import nowon.domain.dto.visual.SaveDto;
import nowon.service.VisualService;

@RequiredArgsConstructor
@Controller
public class VisualController {
	
	private final VisualService service;
	
	@GetMapping("/admin/visualpage")
	public String visualpage() {
		return "admin/visual/write";
	}
	
	@PostMapping("/admin/visuals")
	public String Save(MultipartFile visualFile, SaveDto dto) throws IOException{
		service.saveAndFileUpload(visualFile, dto);
		return "admin/visual/write";
	}
}
